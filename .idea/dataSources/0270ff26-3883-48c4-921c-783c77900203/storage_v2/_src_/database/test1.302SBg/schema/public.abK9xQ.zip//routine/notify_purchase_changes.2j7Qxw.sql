create function notify_purchase_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    PERFORM pg_notify(
            'purchase_changed',
            json_build_object(
                    'operation', TG_OP,
                    'record', row_to_json(NEW)
                )::text
        );

    RETURN NEW;
END;
$$;

alter function notify_purchase_changes() owner to test1;

